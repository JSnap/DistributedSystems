package activitystreamer.server;

public class ServerAnnounceMessage extends Message {
	
	private String id = null;
	private int load;
	private String hostname = null;
	private int port;
	
	public ServerAnnounceMessage(){
		super();
	}


	public ServerAnnounceMessage(String id, int load, String hostname, int port){
		this.command = "SERVER_ANNOUNCE";
		this.id = id;
		this.load = load;
		this.hostname = hostname;
		this.port = port;
	}

	public String getId() {
		return id;
	}

	public int getLoad() {
		return load;
	}


	public void setLoad(int load) {
		this.load = load;
	}


	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	
	

}
