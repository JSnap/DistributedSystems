package activitystreamer.server;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import activitystreamer.util.Settings;


public class Connection extends Thread {
	private static final Logger log = LogManager.getLogger();
	private DataInputStream in;
	private DataOutputStream out;
	private BufferedReader inreader;
	private PrintWriter outwriter;
	private boolean open = false;
	private Socket socket;
	private boolean term=false;
	
	//MY VARIABLES
	private boolean authenticated = false;
	private boolean server = false;
	
	//Constructor
	Connection(Socket socket) throws IOException{
		//From Socket
		in = new DataInputStream(socket.getInputStream());
		
		//To a Socket
	    out = new DataOutputStream(socket.getOutputStream());
	    
	    //Reader
	    inreader = new BufferedReader( new InputStreamReader(in));
	    
	    //Writer
	    outwriter = new PrintWriter(out, true);
	    
	    //Initialise the socket based on input to method
	    this.socket = socket;
	    
	    //Open corresponds to open connection is TRUE = OPEN
	    open = true;
	    
	    //Start the thread
	    start();
	}
	
	/*
	 * returns true if the message was written, otherwise false
	 */
	public boolean writeMsg(String msg) {
		
		//if socket connection is open
		if(open){
			//write message
			outwriter.println(msg);
			
			//make sure that is writes it
			outwriter.flush();
			return true;	
		}
		
		//If connection is closed then do nothing and return.
		return false;
	}
	
	public void closeCon(){
		if(open){
			//logging
			log.info("closing connection "+Settings.socketAddress(socket));
			try {
				//close connection
				term=true;
				//close the reader
				inreader.close();
				//close the writer
				out.close();
			} catch (IOException e) {
				// already closed?
				log.error("received exception closing the connection "+Settings.socketAddress(socket)+": "+e);
			}
		}
	}
	
	//After thread start(), it calls run() by itself.
	public void run(){
		try {
			//Define a string to be used later.
			String data;
			//While connection is open and there is stuff to read
			while(!term && (data = inreader.readLine())!=null){
				
				//process returns true if the connection should close
				term=Control.getInstance().process(this,data);
			}
			
			//log some information
			log.debug("connection closed to "+Settings.socketAddress(socket));
			
			//Remove this connection from the ArrayList
			Control.getInstance().connectionClosed(this);
			//Close data input stream
			in.close();
		} catch (IOException e) {
			log.error("connection "+Settings.socketAddress(socket)+" closed with exception: "+e);
			//remove connection from arraylist
			Control.getInstance().connectionClosed(this);
		}
		open=false;
	}
	
	public Socket getSocket() {
		return socket;
	}
	
	public boolean isOpen() {
		return open;
	}
	
	//My METHOD FOR AUTHENTICATION
	public boolean isAuthenticated(){
		return authenticated;
	}
	
	public void setAuthenticationStatus(boolean status){
		this.authenticated = status;
	}
	
	public boolean isServer(){
		return this.server;
	}
	
	public void setServer(boolean status){
		this.server = status;
	}
	
}
