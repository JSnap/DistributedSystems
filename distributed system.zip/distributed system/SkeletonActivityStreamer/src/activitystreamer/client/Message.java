package activitystreamer.client;

import activitystreamer.util.*; 

public class Message {
	
	protected String command = null;
	private String secret = null;
	private String info = null;
	private String username="anonymous";
	private String remoteHost = null;
	private int remoteport;
	private String localHostname=null;
	private int localport;
	
	public Message(){
	}	

	public String getCommand() {
		return command;
	}
	
	public void loginsuccessMessage(String username){
		this.command = "LOGIN_SUCCESS";
		this.info = "logged in as user "+username;
	}
	
	public void loginfailMessage(){
		this.command = "LOGIN_FAILED";
		this.info ="attempt to login with wrong secret";
		
	}
	
	public void logoutMessage(){
		this.command = "LOGOUT";
		this.info = "logout user "+username;
	}
	
	public void loginMessage(){
		this.command="LOGIN";
	}
	//override
	public void loginMessage(String username,String secret){
		this.command="LOGIN";
		this.setUsername(username); 
		this.setSecret(secret);
		
	}
	
	public void redirectserverMessage(String remoteHost, int remoteport){
		this.command="REDIRECT";
		this.setRemoteHost(remoteHost);
		this.setRemoteport(remoteport);
	}
	
	public void register(String username){
		this.command="REGISTER";
		this.setUsername(username);
	}
	
	public static String[] validCommands(){
		String[] str = new String[17];
		
		str[0] = "AUTHENTICATE";
		str[1] = "AUTHENTICATION_FAIL";
		str[2] = "INVALID_MESSAGE";
		str[3] = "LOGIN";
		str[4] = "LOGIN_SUCCESS";
		str[5] = "REDIRECT";
		str[6] = "LOGIN_FAILED";
		str[7] = "LOGOUT";
		str[8] = "ACTIVITY_MESSAGE";
		str[9] = "SERVER_ANNOUNCE";
		str[10] = "ACTIVITY_BROADCAST";
		str[11] = "REGISTER";
		str[12] = "REGISTER_FAILED";
		str[13] = "REGISTER_SUCCESS";
		str[14] = "LOCK_REQUEST";
		str[15] = "LOCK_DENIED";
		str[16] = "LOCK_ALLOWED";
		
		return str;
	}
	
	public static boolean checkCommand(String cmd){
		String str[] = Message.validCommands();
		
		int size = str.length;
		for(int i=0; i < size; i++){
			if(str[i].equals(cmd)){
				return true;
			}
		}
		
		return false;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
	
	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	//For Testing Purposes
	public void incorrectMessage(){
		this.command = "authenticate";
	}

	public String getRemoteHost() {
		return remoteHost;
	}

	public void setRemoteHost(String remoteHost) {
		this.remoteHost = remoteHost;
	}

	public int getRemoteport() {
		return remoteport;
	}

	public void setRemoteport(int remoteport) {
		this.remoteport = remoteport;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setlocalHostname(){
		this.localHostname=Settings.getLocalHostname();
	}
	
	public String getlocalHostname(){
		return localHostname;
	}
	
	public void setlocalport(){
	    this.localport=Settings.getLocalPort();
	}
	
	public int getlocalport(){
		return localport;
	}

}
