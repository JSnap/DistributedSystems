package activitystreamer.server;

import java.io.IOException;

import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
//import java.util.function.Consumer;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

import activitystreamer.util.Settings;



public class ControlSolution extends Control {
	private static final Logger log = LogManager.getLogger();
	private String id;
	private int load = 100; //number of clients connected to server


	/*
	 * additional variables as needed
	 */

	// since control and its subclasses are singleton, we get the singleton this way
	public static ControlSolution getInstance() {
		if(control==null){
			control=new ControlSolution();
		} 
		return (ControlSolution) control;
	}

	public ControlSolution() {
		//Call the superclass constructor (Control)
		/*Creates an ArrayList for Connections
		 *Creates a Listener on local port
		 */
		super();

		/*
		 * Do some further initialization here if necessary
		 */

		this.id = Settings.nextSecret();

		//SECRET SETUP
		String secret;
		if (Settings.getSecret() == null){
			//If a Secret hasn't been set then generate one
			secret = Settings.nextSecret();
			Settings.setSecret(secret);
			System.out.println("\n\nSecret = " + secret + "\n\n");
		} else {
			//Assign the secret in settings
			secret = Settings.getSecret();
		}




		// check if we should initiate a connection and do so if necessary
		initiateConnection();
		/* Method of superclass (Control)
		 * Generates an outgoing connection to remotehost
		 */


		// start the server's activity loop
		// it will call doActivity every few seconds
		start();
	}


	/*
	 * a new incoming connection
	 */
	@Override
	public Connection incomingConnection(Socket s) throws IOException{
		Connection con = super.incomingConnection(s);
		/*
		 * do additional things here
		 *
		 */


		return con;
	}

	/*
	 * a new outgoing connection
	 */
	@Override
	public Connection outgoingConnection(Socket s) throws IOException{

		//Creates connection object and adds to ArrayList
		Connection con = super.outgoingConnection(s);

		//Authenticate
		sendAuthenticationMessage(con);
		//Trust the Server we are connecting to (so we can receive their responses)
		con.setAuthenticationStatus(true);
		con.setServer(true);

		/*sendIncorrectMessage(con);*/

		return con;
	}


	/*
	 * the connection has been closed
	 */
	@Override
	public void connectionClosed(Connection con){
		super.connectionClosed(con);
		/*
		 * do additional things here
		 */
	}


	/*
	 * process incoming msg, from connection con
	 * return true if the connection should be closed, false otherwise
	 */
	@Override
	public synchronized boolean process(Connection con,String msg){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */

		Gson gson = new Gson();
		Message receivedMsg = new Message();

		log.debug("Received Message:\n" + msg);

		try{
			receivedMsg = gson.fromJson(msg, Message.class);
		} catch (JsonParseException e){
			sendInvalidMessage(con, "JSON parse error while parsing message");
			con.closeCon();
			return true;
		}

		//Check Command
		String command = receivedMsg.getCommand();
		if (command == null){
			sendInvalidMessage(con,"the received message did not contain a command");
			//close the connection
			con.closeCon();
			return true;

		} else{
			boolean validCommand = Message.checkCommand(command);
			if (!validCommand){
				sendInvalidMessage(con,"the received message did not contain a valid command");
				//close the connection
				con.closeCon();
				return true;
			}	
		}

		//Authentication
		if (!con.isAuthenticated()){
			if (command.equals("AUTHENTICATE")){
				if (receivedMsg.getSecret().equals(Settings.getSecret())){
					log.debug("authentication successful");
					con.setAuthenticationStatus(true);
					con.setServer(true);
					return false;
				} else{
					con.setAuthenticationStatus(false);
					log.debug("authentication unsuccessful - invalid secret");
					sendAuthenticationFailMessage(con,receivedMsg.getSecret());
					//close the connection
					con.closeCon();
					return true;
				}
			} else {
				sendInvalidMessage(con,"first command must be AUTHENTICATE");
				//close the connection
				con.closeCon();
				return true;
			}

		}

		if (con.isAuthenticated() && command.equals("AUTHENTICATE")){
			sendInvalidMessage(con,"already successfully authenticated");
			//close the connection
			con.closeCon();
			return true;
		}


		//Receive INVALID_MESSAGE
		if (command.equals("INVALID_MESSAGE")){
			//close the connection
			con.closeCon();
			return true;
		}

		//Receive AUTHENTICATION_FAIL
		if (command.equals("AUTHENTICATION_FAIL")){
			con.closeCon();
			//close the connection
			return true;
		}

		if (command.equals("SERVER_ANNOUNCE")){
			ServerAnnounceMessage servMsg = new ServerAnnounceMessage();
			servMsg = gson.fromJson(msg, ServerAnnounceMessage.class);
			ArrayList<Connection> connections = Control.getInstance().getConnections();

			//Broadcast to all except connection it came in on.
			for (Connection connection : connections){
				if (!connection.equals(con) && connection.isServer()){
					forwardServerAnnounceMessage(connection, servMsg);
				}
				
			}
			//Use Received Information to construct Array or such
			//to store load, listening port and hostname of remote host
			int serverLoad = servMsg.getLoad();
			String remoteHost = servMsg.getHostname();
			int remotePort = servMsg.getPort();

			return false;
		}


		return false;
	}



	/*
	 * Called once every few seconds
	 * Return true if server should shut down, false otherwise
	 */
	@Override
	public boolean doActivity(){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */
		log.debug("Control Solution doActivity()");
		log.debug("Num of Connections = " + Control.getInstance().getConnections().size());

		//Find all servers connected (NEED TO DIFFERENTIATE BETWEEN CLIENTS AND SERVERS EVENTUALLY)
		ArrayList<Connection> connections = Control.getInstance().getConnections();
		for (Connection con : connections){
			if (con.isServer()){
				sendServerAnnounceMessage(con);
			}

		}

		return false;
	}

	/*
	 * Other methods as needed
	 */
	
	private boolean forwardServerAnnounceMessage(Connection con, ServerAnnounceMessage msg){
		Gson gson = new Gson();
		String serialMsg = gson.toJson(msg);
		con.writeMsg(serialMsg);
		return true;
	}

	private boolean sendServerAnnounceMessage(Connection con){

		Message msg = new ServerAnnounceMessage(this.id, this.load, Settings.getLocalHostname(), Settings.getLocalPort());
		Gson gson = new Gson();
		String serialMsg = gson.toJson(msg);
		con.writeMsg(serialMsg);
		return true;

	}

	public boolean sendAuthenticationMessage(Connection con){

		Message msg = new Message();
		msg.authenticationMessage(Settings.getSecret());
		Gson gson = new Gson();
		String serialMsg = gson.toJson(msg);
		con.writeMsg(serialMsg);
		return true;

	}

	public boolean sendAuthenticationFailMessage(Connection con, String wrongSecret){

		Message msg = new Message();
		msg.authenticationFailMessage(wrongSecret);
		Gson gson = new Gson();
		String serialMsg = gson.toJson(msg);
		con.writeMsg(serialMsg);
		return true;

	}

	public boolean sendInvalidMessage(Connection con, String reason){
		Message reply = new Message();
		Gson gson = new Gson();
		reply.invalidMessage(reason);
		String serialMsg = gson.toJson(reply);
		con.writeMsg(serialMsg);
		log.debug("Message Sent:" + reason);
		return true;
	}

	//For Testing Purposes

	public boolean sendIncorrectMessage(Connection con){
		Message msg = new Message();
		/*Gson gson = new Gson();*/
		msg.incorrectMessage();
		con.writeMsg(msg.toString());
		/*String serialMsg = gson.toJson(msg);*/
		/*con.writeMsg(serialMsg);*/
		log.debug("Incorrect Message Sent");
		return true;
	}




}
