package activitystreamer.server;

public class Message {
	
	protected String command = null;
	private String secret = null;
	private String info = null;
	
	public Message(){
	}	

	public String getCommand() {
		return command;
	}
	
	public void authenticationMessage(String secret){
		this.command = "AUTHENTICATE";
		this.setSecret(secret);
	}
	
	public void invalidMessage(String info){
		this.command = "INVALID_MESSAGE";
		this.info = info;
	}
	
	public void authenticationFailMessage(String incorrectSecret){
		this.command = "AUTHENTICATION_FAIL";
		this.info = "the supplied secret is incorrect: " + incorrectSecret;
	}
	
	public static String[] validCommands(){
		String[] str = new String[17];
		
		str[0] = "AUTHENTICATE";
		str[1] = "AUTHENTICATION_FAIL";
		str[2] = "INVALID_MESSAGE";
		str[3] = "LOGIN";
		str[4] = "LOGIN_SUCCESS";
		str[5] = "REDIRECT";
		str[6] = "LOGIN_FAILED";
		str[7] = "LOGOUT";
		str[8] = "ACTIVITY_MESSAGE";
		str[9] = "SERVER_ANNOUNCE";
		str[10] = "ACTIVITY_BROADCAST";
		str[11] = "REGISTER";
		str[12] = "REGISTER_FAILED";
		str[13] = "REGISTER_SUCCESS";
		str[14] = "LOCK_REQUEST";
		str[15] = "LOCK_DENIED";
		str[16] = "LOCK_ALLOWED";
		
		return str;
	}
	
	public static boolean checkCommand(String cmd){
		String str[] = Message.validCommands();
		
		int size = str.length;
		for(int i=0; i < size; i++){
			if(str[i].equals(cmd)){
				return true;
			}
		}
		
		return false;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
	
	public String getInfo() {
		return secret;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	//For Testing Purposes
	public void incorrectMessage(){
		this.command = "authenticate";
	}

}
