package activitystreamer.server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import activitystreamer.util.Settings;



public class ControlSolution extends Control {
	private static final Logger log = LogManager.getLogger();
	private static HashMap<String , RegConfirm> nameRegMap = new HashMap<String , RegConfirm>();
	/*
	 * additional variables as needed
	 */
	private static  HashMap<String,ServerRecord> serverRecord;
	private static  HashMap<String,ClientLogin> clientLogin;
	private static  HashMap<String,ClientRegister> clientRegister;
	private JSONParser parser = new JSONParser();
	public static String id;
	// since control and its subclasses are singleton, we get the singleton this way
	public static ControlSolution getInstance() {
		if(control==null){
			control=new ControlSolution();
		} 
		return (ControlSolution) control;
	}
	
	public ControlSolution() {
		super();
		/*
		 * Do some further initialization here if necessary
		 */
		serverRecord=new HashMap<String,ServerRecord> ();
		clientLogin=new HashMap<String,ClientLogin>();
		clientRegister=new  HashMap<String,ClientRegister>();
		id=Settings.getLocalHostname()+":"+String.valueOf(Settings.getLocalPort());		
		// check if we should initiate a connection and do so if necessary
		initiateConnection();
		// start the server's activity loop
		// it will call doActivity every few seconds
		start();
	}
	
	
	/*
	 * a new incoming connection
	 */
	@Override
	public Connection incomingConnection(Socket s) throws IOException{
		Connection con = super.incomingConnection(s);
		/*
		 * do additional things here
		 */
		
		return con;
	}
	
	/*
	 * a new outgoing connection
	 */
	@Override
	public Connection outgoingConnection(Socket s) throws IOException{
		Connection con = super.outgoingConnection(s);
		/*
		 * do additional things here
		 */
		JSONObject json = new JSONObject();
		json.put("command", "AUTHENTICATE");			
		json.put("secret", Settings.getSecret());
		json.put("server", id);	
		con.writeMsg(json.toJSONString());
		ServerRecord sr=new ServerRecord();
		sr.con=con;
		sr.hostname=Settings.getRemoteHostname();
		sr.port=Settings.getRemotePort();
		String remoteId=sr.hostname+":"+sr.port;
		serverRecord.put(remoteId, sr);
		return con;
	}
	
	
	/*
	 * the connection has been closed
	 */
	@Override
	public void connectionClosed(Connection con){
		super.connectionClosed(con);
		/*
		 * do additional things here
		 */
		Set set=serverRecord.entrySet();
		Iterator  it=set.iterator(); 							  
		while(it.hasNext()){
			Map.Entry me=(Map.Entry)it.next() ;
			ServerRecord sr= (ServerRecord)me.getValue();	
			if(sr.con==con)
			{
				serverRecord.remove(me.getKey());
			}
		}
		
		set=clientLogin.entrySet();
		it=set.iterator(); 							  
		while(it.hasNext()){
			Map.Entry me=(Map.Entry)it.next() ;
			ClientLogin cl= (ClientLogin)me.getValue();	
			if(cl.con==con)
			{
				clientLogin.remove(me.getKey());
			}
		}
		
	}
	
	
	public boolean parseCommand(JSONObject obj)
	{
		if(obj==null) return false;
		if(obj.containsKey("command"))
		{
			String command=(String)obj.get("command");
			if(command.equals("REGISTER")&&obj.containsKey("username") && obj.containsKey("secret"))
				return true;			
			
		}
		return false;
	}
	
	/*
	 * process incoming msg, from connection con
	 * return true if the connection should be closed, false otherwise
	 */
	@Override
	public synchronized boolean process(Connection con,String msg){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */
		
		JSONObject obj;
		try {			
			obj = (JSONObject) parser.parse(msg);			
			if(parseCommand(obj))
			{
				String command=(String) obj.get("command");				
				if(command.equals("REGISTER")) {						
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");
					if(clientRegister.containsKey(username)){
						JSONObject json = new JSONObject();
						json.put("command", "REGISTER_FAILED");
						json.put("info", username+" is already registered with the system");	
						con.writeMsg(json.toJSONString());
					}
					else{
						if( serverRecord.size()==0)	{
							JSONObject json = new JSONObject();
							json.put("command", "REGISTER_SUCCESS");
							json.put("info", "register success for "+username);
							con.writeMsg(json.toJSONString());
							ClientRegister cr=new ClientRegister();						
							cr.secret=secret;
							cr.username=username;
							clientRegister.put(username, cr);
						}				
						else{
							JSONObject json = new JSONObject();
							json.put("command", "LOCK_REQUEST");
							json.put("username", username);
							json.put("secret", secret);
							RegConfirm rc=new RegConfirm();
							rc.allowed= serverRecord.size();
							rc.con=con;
							nameRegMap.put(username, rc);
							
							Set set=serverRecord.entrySet();
							Iterator  it=set.iterator(); 							  
							while(it.hasNext()){
								Map.Entry me=(Map.Entry)it.next() ;
								ServerRecord sr= (ServerRecord)me.getValue();	
								if(sr.con!=null)
								{
									sr.con.writeMsg(json.toJSONString());
								}
							}
							
						}
					}
				}
				if(command.equals("LOCK_REQUEST"))
				{
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");
					if(getServerRecord(con)!=null) { 
						if(clientRegister.containsKey(username))
						{
							ClientRegister cr=clientRegister.get(username);
							if(!cr.secret.equals(secret))
							{
								JSONObject json = new JSONObject();
								json.put("command", "LOCK_DENIED");
								json.put("username", username);
								json.put("secret", secret);								
								Set set=serverRecord.entrySet();
								Iterator  it=set.iterator(); 							  
								while(it.hasNext()){
									Map.Entry me=(Map.Entry)it.next() ;
									ServerRecord sr= (ServerRecord)me.getValue();	
									if(sr.con!=null)
									{
										sr.con.writeMsg(json.toJSONString());
									}
								}
							}
						}
						else{
							ClientRegister cr=new ClientRegister();						
							cr.secret=secret;
							cr.username=username;
							clientRegister.put(username, cr);
							JSONObject json = new JSONObject();
							json.put("command", "LOCK_ALLOWED");
							json.put("username", username);
							json.put("secret", secret);
							json.put("server", id);
							Set set=serverRecord.entrySet();
							Iterator  it=set.iterator(); 							  
							while(it.hasNext()){
								Map.Entry me=(Map.Entry)it.next() ;
								ServerRecord sr= (ServerRecord)me.getValue();	
								if(sr.con!=null){
									sr.con.writeMsg(json.toJSONString());
								}
							}
						}	
					}
					else
					{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", "the server is from an unauthenticated server");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
				}
				
				if(command.equals("LOCK_DENIED"))
				{
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");					
					if(getServerRecord(con)!=null )	{
						if(clientRegister.containsKey(username))
						{
							ClientRegister cr=clientRegister.get(username);
							if(cr.secret.equals(secret))
							{
								clientRegister.remove(username);
							}
						}
						if(nameRegMap.containsKey(username))
						{
							RegConfirm rc=nameRegMap.get(username);
							if(rc.allowed>0)
							{								
								if(rc.con!=null)
								{
									JSONObject json = new JSONObject();
									json.put("command", "REGISTER_FAILED");
									json.put("info", username+" is already registered with the system");	
									rc.con.writeMsg(json.toJSONString());
									connectionClosed(rc.con);
								}
							}
							nameRegMap.remove(username);
						}
					}
					else
					{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", username+" is from an unauthenticated server");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
					
				
				}
				if(command.equals("LOCK_ALLOWED"))
				{
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");
					String serId=(String)obj.get("server");
					if(serverRecord.containsKey(serId))	{
						if(nameRegMap.containsKey(username))
						{
							RegConfirm rc=nameRegMap.get(username);	
							if(rc.allowed>0)
							{
								rc.allowed--;								
								if(rc.allowed==0)
								{									
									if(rc.con!=null)
									{
										JSONObject json = new JSONObject();
										json.put("command", "REGISTER_SUCCESS");
										json.put("info", "register success for "+username);	
										rc.con.writeMsg(json.toJSONString());
										nameRegMap.remove(username);
									}
								}
							}							
							
						}
					}
					else
					{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", username+" is from an unauthenticated server");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
				
				}
				if(command.equals("INVALID_MESSAGE"))
				{
					connectionClosed(con);
				}
				if(command.equals("SERVER_ANNOUNCE"))
				{
					String id=(String)obj.get("id");
					if(!serverRecord.containsKey(id))	{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", id+" is from an unauthenticated server");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
					else
					{
						ServerRecord sr=serverRecord.get(id);
						int load=(int)obj.get("load");
						String hostname=(String)obj.get("hostname");
						int port=(int)obj.get("port");
						sr.load=load;
						sr.hostname=hostname;
						sr.port=port;
						sr.con=con;
					}
				
				}
				if(command.equals("AUTHENTICATE"))
				{					
					if(getServerRecord(con)!=null)
					{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", "the server has been authenticated");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
					else 
					{
						String secret=(String)obj.get("secret");
						if(!secret.equals(Settings.getSecret()))
						{
							JSONObject json = new JSONObject();
							json.put("command", "AUTHENTICATION_FAIL");
							json.put("info", "the supplied secret is incorrect: "+secret);
							con.writeMsg(json.toJSONString());
							connectionClosed(con);
						}
						else
						{
							String serId=(String)obj.get("server");
							ServerRecord sr=new ServerRecord();
							sr.id=serId;
							sr.con=con;							
							serverRecord.put(serId, sr);
						}
					}
				}
				
				if(command.equals("LOGIN"))
				{
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");
					if(username.equals("anonymous")||(clientRegister.containsKey(username)&&clientRegister.get(username).equals(secret)))
					{
						JSONObject json = new JSONObject();
						json.put("command", "LOGIN_SUCCESS");
						json.put("info", "logged in as user "+username);
						con.writeMsg(json.toJSONString());
						
						Iterator it=serverRecord.entrySet().iterator();
						while(it.hasNext())
						{
							Map.Entry me=(Map.Entry)it.next() ;
							ServerRecord sr=(ServerRecord)me.getValue();
							if(clientLogin.size()-2>=sr.load)
							{
								json = new JSONObject();
								json.put("command", "REDIRECT");
								json.put("hostname", sr.hostname);
								json.put("port", sr.port);								
								con.writeMsg(json.toJSONString());
								connectionClosed(con);
								return false;
							}
						}
						ClientLogin cl=new ClientLogin();
						cl.username=username;
						cl.secret=secret;
						cl.con=con;
						clientLogin.put(username, cl);
					}
					else
					{						

						JSONObject json = new JSONObject();
						json.put("command", "LOGIN_FAILED");
						json.put("info", "attempt to login with wrong secretr ");
						con.writeMsg(json.toJSONString());
					}
				}
				
				if(command.equals("LOGOUT"))
				{
					connectionClosed(con);
				}
				
				if(command.equals("ACTIVITY_MESSAGE"))
				{
					String username=(String)obj.get("username");
					String secret=(String)obj.get("secret");
					if(username.equals("anonymous")||(clientLogin.containsKey(username)&&clientLogin.get(username).equals(secret)))
					{					
						JSONObject activity=(JSONObject)obj.get("activity");
						JSONObject json = new JSONObject();
						json.put("command", "ACTIVITY_BROADCAST");
						json.put("username", username);
						json.put("activity", activity);
						Set set=serverRecord.entrySet();
						Iterator  it=set.iterator(); 							  
						while(it.hasNext()){
							Map.Entry me=(Map.Entry)it.next() ;
							ServerRecord sr= (ServerRecord)me.getValue();	
							if(sr.con!=null){
								sr.con.writeMsg(json.toJSONString());
							}
						}
					}
					else
					{
						JSONObject json = new JSONObject();
						json.put("command", "AUTHENTICATION_FAIL");
						json.put("info", "the supplied secret is incorrect: "+secret);
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
				}
				
				if(command.equals("ACTIVITY_BROADCAST"))
				{
					ServerRecord sr=getServerRecord(con);
					if(sr!=null)
					{
						Set set=clientLogin.entrySet();
						Iterator  it=set.iterator(); 							  
						while(it.hasNext()){
							Map.Entry me=(Map.Entry)it.next() ;
							ClientLogin cl= (ClientLogin)me.getValue();	
							if(cl.con!=null){
								cl.con.writeMsg(obj.toJSONString());
							}
						}
					}
					else
					{
						JSONObject json = new JSONObject();
						json.put("command", "INVALID_MESSAGE");
						json.put("info", " unauthenticated server");
						con.writeMsg(json.toJSONString());
						connectionClosed(con);
					}
				}
				
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/*
	 * judge the connection is valid
	 */
	
	ServerRecord getServerRecord(Connection con)
	{
		Set set=serverRecord.entrySet();
		Iterator  it=set.iterator(); 							  
		while(it.hasNext()){
			Map.Entry me=(Map.Entry)it.next() ;
			ServerRecord sr= (ServerRecord)me.getValue();	
			if(sr.con==con){
				return sr;
			}
		}
		return null;
	}
	
	
	/*
	 * Called once every few seconds
	 * Return true if server should shut down, false otherwise
	 */
	@Override
	public boolean doActivity(){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */
		JSONObject json = new JSONObject();
		json.put("command", "SERVER_ANNOUNCE");
		json.put("id", id);	
		json.put("load", clientLogin.size());
		json.put("hostname", Settings.getLocalHostname());
		json.put("port", Settings.getLocalPort());
		Set set=serverRecord.entrySet();
		Iterator  it=set.iterator(); 							  
		while(it.hasNext()){
			Map.Entry me=(Map.Entry)it.next() ;
			ServerRecord sr= (ServerRecord)me.getValue();	
			if(sr.con!=null){
				sr.con.writeMsg(json.toJSONString());
			}
		}
		
		return false;
	}
	
	/*
	 * Other methods as needed
	 */
	class ServerRecord
	{
		public String id;
		public int load;
		public String hostname;
		public int port;
		public Connection con;
	}
	class ClientLogin
	{
		public String username;
		public String secret;	
		public Connection con;
	}	
	
	class ClientRegister
	{
		public String username;
		public String secret;
	
	}
	
	class RegConfirm
	{
		public int allowed;
		public Connection con;
	}
	
}
