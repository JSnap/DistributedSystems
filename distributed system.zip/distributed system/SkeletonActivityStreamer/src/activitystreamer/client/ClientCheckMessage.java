package activitystreamer.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import activitystreamer.util.Settings;

import com.google.gson.Gson;

public class ClientCheckMessage {
	private static final Logger log = LogManager.getLogger();
	private String remoteHost=null;
	private int remoteport;
	private String secret;
	private String username;
	private boolean open = false;
	private boolean term = true;
	private Socket clientsocket;
	private DataInputStream in;
	private DataOutputStream out;
	private BufferedReader inreader;
	private PrintWriter outwriter;
	
	public ClientCheckMessage(){
		this.remoteHost=Settings.getRemoteHostname();
		this.remoteport=Settings.getRemotePort();
		this.secret=Settings.getSecret();
		this.username=Settings.getUsername();
			
		try{
			
		this.clientsocket=new Socket(remoteHost,remoteport);
			
        in = new DataInputStream(clientsocket.getInputStream());
		
	    out = new DataOutputStream(clientsocket.getOutputStream());
	    
	    inreader = new BufferedReader( new InputStreamReader(in));
	    
	    outwriter = new PrintWriter(out, true);
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	}

	public void register(){
		
	} 
	
	//include login check and register
	public void loginCheckSend(){
		String username = this.username;
		String secret = this.secret;		
		try{	
			
			Gson gson=new Gson();
			Message msg= new Message();
			//check if username/anonymous and secret exists do login
			if (username!=null && secret!=null){
			//send login message need return login success/fail/invalid
				msg.loginMessage(username, secret);
			}else{
				msg.loginMessage();//anonymous 
			}
			//check if no secret do register  
			if(username!=null && secret ==null){
		    //send register message need server info secret return register fail/success/invalid 	
				msg.register(username);
			}
			String logmsg = gson.toJson(msg);
			outwriter.print(logmsg);
			outwriter.flush();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//check message command from server after send login require 
	public boolean loginCheckReceive(){
		boolean result=false;
		try{
			Gson gson =new Gson();
			String data;
			data=inreader.readLine();
			Message recieveMsg = new Message();
			recieveMsg = gson.fromJson(data, Message.class);
			String command= recieveMsg.getCommand();
			if (command=="LOGIN_FAILED"){
			    log.info("attempt to login with wrong secret");
			    term = true;	
			    open = false;
				inreader.close();
				outwriter.close();
				clientsocket.close();
				result = false;
			}
			if(command=="LOGIN_SUCCESS"){
				log.info("logged in as"+username);
				open = true;
				term = false;
				result = true;
			}
			if(command=="REDIRECT"){
				log.info("need to redirect");
				clientsocket.close();
				//need new remotehost and remoteport
				this.remoteHost=recieveMsg.getRemoteHost();
				this.remoteport=recieveMsg.getRemoteport();
				Socket newclientsocket =new Socket(remoteHost,remoteport);
				this.clientsocket=newclientsocket;
				open = true;
				term = false;
				result = true;
			}
			if(command == "INVALID_MESSAGE"){
				log.info(recieveMsg.getInfo());
				term = true;
				open = false;
				inreader.close();
				outwriter.close();				
				clientsocket.close();
				result = false;
			}
			if (command == "REGISTER_FAILED"){
				log.info(username+"is already registered with the system");	
				term = true;
				open = false;
				inreader.close();
				outwriter.close();
				clientsocket.close();
				result = false;
			}
			if (command == "REGISTER_SUCCESS"){
				log.info("register success for"+username);
				term = false;
				open = true;
				result = true;
			}
		}catch(Exception e){
			log.error("recieve exception error:"+e);
		}
		return result;
	}
	
	public Socket getSocket(){
		return clientsocket;
	}
	
	public void disconnect(){
		if (open){
			log.info("closing connection"+Settings.socketAddress(clientsocket));
			try{
				term=true;
				open=false;
				inreader.close();
				out.close();
				clientsocket.close();
			}catch(IOException e){
				log.error("received exception closing the connection "+Settings.socketAddress(clientsocket)+": "+e);
			}
		}
	}
	
}
