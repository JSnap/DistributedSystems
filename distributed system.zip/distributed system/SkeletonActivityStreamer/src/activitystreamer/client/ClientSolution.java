package activitystreamer.client;


import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.*;

import activitystreamer.util.Settings;
import java.net.*;
import java.io.*;


public class ClientSolution extends Thread {
	private static final Logger log = LogManager.getLogger();
	private static ClientSolution clientSolution;
	private TextFrame textFrame;
	private Socket clientsocket;
	private DataInputStream in;
	private DataOutputStream out;
	private BufferedReader inreader;
	private PrintWriter outwriter;
	private boolean open = false;
	private boolean term = true; 
	
	/*
	 * additional variables
	 */
	
	// this is a singleton object
	public static ClientSolution getInstance(){
        if(clientSolution==null){
			
				clientSolution = new ClientSolution();
		}
		return clientSolution;
	}
	
	public ClientSolution() {
		/*
		 * some additional initialization
		 */	
		ClientCheckMessage clsm = new ClientCheckMessage();
		clsm.loginCheckSend();
		if(clsm.loginCheckReceive()){	
		this.clientsocket=clsm.getSocket();
		}else{
			log.info("attempt to login with wrong secret");
			clsm.disconnect();
		}
		open = true;
				
		// open the gui
		log.debug("opening the gui");
		textFrame = new TextFrame();
		// start the client's thread
		start();
	}
	
	// called by the gui when the user clicks "send"
	//send info
	public void sendActivityObject(JSONObject activityObj){
		try {
			if(open){
			    out = new DataOutputStream(clientsocket.getOutputStream());
			    outwriter= new PrintWriter(out,true);			
			    outwriter.print(activityObj.toString());		    
			    outwriter.flush();
		      }
			} catch (IOException e) {
			log.error("recieve exception send message"+Settings.socketAddress(clientsocket)+": "+e);
		}
		
	}
	
	// called by the gui when the user clicks disconnect
	public void disconnect(){
		textFrame.setVisible(false);
		/*
		 * other things to do
		 */
		if (open){
			log.info("closing connection"+Settings.socketAddress(clientsocket));
			try{
				//send log out message to server
				Message logoutmessage = new Message();
				Gson gson =new Gson();
				logoutmessage.logoutMessage();
				String logoutmsg = gson.toJson(logoutmessage);
				outwriter.print(logoutmsg);
				outwriter.flush();
				term=true;
				open=false;
				inreader.close();
				out.close();
				clientsocket.close();
			}catch(IOException e){
				log.error("received exception closing the connection "+Settings.socketAddress(clientsocket)+": "+e);
			}
		}
	}
	

	// the client's run method, to receive messages
	//receive message from server
	@Override
	public void run(){			
		try {
			String clientdata;	
			JSONParser parser =new JSONParser();
			while(!term && inreader.readLine()!=null){
				in =new DataInputStream(clientsocket.getInputStream());
				inreader = new BufferedReader(new InputStreamReader(in));
				clientdata=inreader.readLine();
				JSONObject obj = (JSONObject)parser.parse(clientdata);				
				textFrame.setOutputText(obj);
				
				
			}
		} catch (Exception e) {
			log.error("connection "+Settings.socketAddress(clientsocket)+" closed with exception: "+e);
			// TODO Auto-generated catch block
		}
	}


	/*
	 * additional methods
	 */
		public void setClientsocket(Socket s){
			this.clientsocket=s;
		}
//this socket use for first connection and check	
	
}
